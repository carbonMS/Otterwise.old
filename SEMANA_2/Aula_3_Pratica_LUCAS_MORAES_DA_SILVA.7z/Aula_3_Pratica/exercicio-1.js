// 1 - Imprima no console os valores de 1 até 25.

for (let index = 1; index < 26; index++) console.log(index);
