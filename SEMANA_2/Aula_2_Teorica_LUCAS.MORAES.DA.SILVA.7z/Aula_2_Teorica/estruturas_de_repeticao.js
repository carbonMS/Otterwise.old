// imprima no console 15 vezes a palavra "formação web developer"
for (let index = 0; index < 15; index++) {
  console.log("formação web developer" + index);
}

//index começa contando sempre do 0
