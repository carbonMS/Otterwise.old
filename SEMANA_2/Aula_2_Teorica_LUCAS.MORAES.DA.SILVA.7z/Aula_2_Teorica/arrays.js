//ARRAY = LISTA DE ELEMENTOS
//SEMPRE É COM COLCHETES []

const myArray = ["Lucas", "João", "Paulo"];

// //Crie um algoritmo que imprime todos os valores de um array qualquer, menos o ultimo elemento.

for (let index = 0; index < myArray.length; index++) {
  if (index === myArray.length - 1) console.log(myArray[index]);
}

// Tendo como array de entrada [10, 20, 30, 40, 50], multiplique o conteudo por 2 e printe na tela ao final

// const entryArray = [10, 20, 30, 40, 50];
// function multiplyArray(entry) {
//   if (entryArray);
//   console.log(entryArray * 2);
// }

//OBJETO É UMA LISTA DE PROPRIEDADES

// https://www.w3schools.com/
// https://developer.mozilla.org/pt-BR/
