// 3. Levando em consideração o array [6, 21, 9, 2, 50, 98, 1] crie uma função que
//  mostra o maior numero da lista

let myArray = [6, 21, 9, 2, 50, 98, 1];
let add = 0;

function highNumber() {
  for (let index = 0; index < myArray.length; index++) {
    myArray[index] > add;
  }
}

console.log(highNumber());
console.log(add);
