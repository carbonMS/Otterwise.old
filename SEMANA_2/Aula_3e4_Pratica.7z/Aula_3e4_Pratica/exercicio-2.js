// 2 - Imprima no console os valores de 10 até 200 de 10 em 10.

let a = 10;

for (let index = 1; index < 21; index++) console.log(index * 10);
