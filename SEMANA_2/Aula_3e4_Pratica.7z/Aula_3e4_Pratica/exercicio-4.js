// 4 - Construa um objeto chamado myUser que possui as propriedades: name,
// age e email, coloque valores de sua escolha nessas propriedades e imprima o
// objeto no console.
// Exemplo Saída:
// { name: 'Juca', age: 25, email: 'juca@gmail.com' }

myUser = {
  name: "Juca",
  age: 25,
  email: "juca@gmail.com",
};

console.log(myUser);
