// 04 - Faça um programa que receberá a hora inicial e a hora final de um jogo. A
// seguir calcule a duração do jogo, sabendo que o mesmo pode começar em um
// dia e terminar em outro, tendo uma duração máxima de 24 horas.

let fullDay = 24;

function gameTime(startTime, endTime) {
  if (startTime <= 24 && endTime <= 24 && startTime >= endTime)
    return startTime - fullDay + endTime + " horas totais.";
  else if (endTime <= startTime)
    return endTime - fullDay + endTime + " horas totais. 2";
}
console.log(gameTime(18, 3));
